Real-Time Chat Application 

1. Project Overview
The Real-Time Chat Application is a web-based platform that enables multiple users to communicate instantly in a shared chat room. Built using Node.js, Express, and Socket.io, the app facilitates real-time, bi-directional communication via WebSockets. Users can join the chat by entering a unique username, send and receive messages, view who else is online, and access previous chat messages upon joining. This project demonstrates the power of Node.js’s event-driven, non-blocking I/O architecture for building scalable and responsive web applications.
2. Installation
Prerequisites
Ensure you have Node.js installed (recommended version 14 or higher).
Install Dependencies:

Navigate to your project folder and run: npm install
Usage
Starting the Application
Run the Node.js server with the command: node server.js
Accessing the Chat
Open your web browser and go to: http://localhost:3000
You will be prompted to enter a username. After joining, you can:

Send messages to the chat room.

See messages from other users in real time.

View a list of currently online users.

Open multiple browser windows or tabs to simulate multiple users.

4. Features
Real-Time Chat
The core feature uses Socket.io to enable instant message exchange between clients and the server over WebSocket connections. Messages are broadcast to all connected users immediately after sending.

Message History
The server maintains the last 20 messages in memory. When a new user connects, the server sends these past messages to provide chat context and continuity.

User List
The application tracks connected users, displaying an updated list of online usernames. The list updates dynamically as users join or leave.
Unique User Colors
Each user is assigned a consistent unique color displayed alongside their messages and username in the chat, improving message readability.

Scalability
Built on Node.js’s non-blocking, event-driven model, the app efficiently handles many concurrent WebSocket connections. This architecture enables scalability horizontally across multiple instances with load balancing.
Deployment
Hosting Options
Heroku: Easy deployment with free tiers available.

Render: Supports Node.js apps with automatic HTTPS.

DigitalOcean / AWS: Suitable for more control and scaling.

Basic Deployment Steps on Heroku
Login to Heroku CLI and create an app: heroku login
heroku create "sholachat app"
Push your code to Heroku: git push heroku main
Open your deployed app: heroku open
Modify server.js to use dynamic port assignment for compatibility: const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
Instructions for Running the Code
Run npm install to install all dependencies.

Start the server using node server.js.

Open a browser and visit http://localhost:3000.

Multiple users can join from different devices or browser tabs.

Messages and user lists update instantly.

To stop the server, press Ctrl+C in the terminal.
Performance Metrics and Scalability Testing
Performance Considerations
Event-Driven Model: Node.js handles I/O asynchronously, allowing high throughput with low latency.

WebSocket Communication: Socket.io uses efficient persistent connections for real-time interaction.

In-memory Storage: Message history is stored in RAM for fast access, suitable for moderate loads.

Scalability Testing Tools
Artillery: Load testing tool to simulate many users and messages.

Autocannon: Fast HTTP/1.1 benchmarking tool for Node.js servers.

Expected Results
Able to handle thousands of concurrent socket connections on a sufficiently powerful server.

Minimal CPU and memory usage under typical chat loads.

Horizontal scaling possible by running multiple server instances behind a load balancer.
