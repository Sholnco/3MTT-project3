const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const users = {}; 

// Serve static files from the "public" folder
app.use(express.static('public'));

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  // When a user sets their username
  socket.on('set username', (username) => {
    users[socket.id] = username;
    console.log('Username set:', username);
    // Update all clients with the new user list
    io.emit('user list', Object.values(users));
    // Broadcast a system message to everyone
    io.emit('chat message', `⚡ ${username} joined the chat`);
  });

  // Listen for chat messages from clients
  socket.on('chat message', (msg) => {
    // Broadcast the message to all connected clients
    io.emit('chat message', msg);
  });

  // When a user disconnects
  socket.on('disconnect', () => {
    const username = users[socket.id];
    if (username) {
      console.log('User disconnected:', username);
      // Remove the user from the list
      delete users[socket.id];
      // Update user list for all clients
      io.emit('user list', Object.values(users));
      // Broadcast a system message
      io.emit('chat message', `⚡ ${username} left the chat`);
    }
  });
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
